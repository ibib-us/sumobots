IBiB Sumobots
1 � 3D print the four pieces of the sumobot: body, lid, fender, and blade
2 � Open your kit and check out the parts preparation document to complete any pre-build instructions
3 � Follow the build instructions to build your sumobot
5 � The instructions for updating the firmware for your microcontroller are found here: https://github.com/CytronTechnologies/MAKER-PI-RP2040/blob/main/setup-circuitpython.md. The latest firmware is in this zip folder, so no need to download anything else; it�s the one with the very long filename that begins with �Adafruit-circuitpython-cytron�
6 � Install the library for the distance sensor. The filename is Adafruit_vl53l0x.mpy and is located in this zip folder.  It should go into the �lib� directory on your circuitpy drive.
7 � Install one of the code bases. There are two: the original codebase (called basic) and a newer version (called fsm). Drag the contents of one of those folders into your circuitpy directory and the microcontroller will automatically reset.
At this point, you should have a working build, or are ready to do some build troubleshooting. Reach out to someone at IBiB if you are having problems.
7 � Check out the rules when you are ready to compete or are interested in being creative with your build.
